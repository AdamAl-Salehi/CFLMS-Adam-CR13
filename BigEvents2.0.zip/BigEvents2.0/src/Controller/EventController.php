<?php
namespace App\Controller;

// We need to import Response, Route, Request and Controller if we want to use them
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route ;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

use Symfony\Component\Form\Extension\Core\Type\TextType ;
use Symfony\Component\Form\Extension\Core\Type\TextareaType ;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use App\Entity\Event ;

/**
 * @Route("/test")
 */
class EventController extends AbstractController
{
    /**
     * @Route("/", name="test_index")
     */
    public function showAction()
    {
         // Here we will use getDoctrine to use doctrine and we will select the entity that we want to work with and we used findAll() to bring all the information from it and we will save it inside a variable named events and the type of the result will be an array
        $events = $this->getDoctrine()->getRepository( 'App:Event')->findAll();
      
        return $this ->render('event/index.html.twig', array('events'=>$events));
 // we send the result (the variable that have the result of bringing all info from our database) to the index.html.twig page
    }
 
 
     /**
     * @Route("/new", name="test_new", methods={"GET","POST"})
     */
    public function  createAction(Request $request)
    {
         // Here we create an object from the class that we made
        $event = new Event;
 /* Here we will build a form using createFormBuilder and inside this function we will put our object and then we write add then we select the input type then an array to add an attribute that we want in our input field */
        $form = $this->createFormBuilder($event)->add( 'name', TextType::class, array ('attr' => array ('class'=> 'form-control' , 'style'=> 'margin-bottom:15px')))
        ->add( 'image', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px')))
        ->add( 'description', TextareaType::class, array( 'attr' => array( 'class'=> 'form-control' , 'style' => 'margin-bottom:15px' )))
        ->add( 'address', TextType::class, array( 'attr' => array( 'class'=> 'form-control' , 'style' => 'margin-bottom:15px' )))
        ->add( 'capacity', TextType::class, array( 'attr' => array( 'class'=> 'form-control' , 'style' => 'margin-bottom:15px' )))
        ->add( 'email', TextType::class, array( 'attr' => array( 'class'=> 'form-control' , 'style' => 'margin-bottom:15px' )))
        ->add( 'phone', TextType::class, array( 'attr' => array( 'class'=> 'form-control' , 'style' => 'margin-bottom:15px' )))
        ->add( 'website', TextType::class, array( 'attr' => array( 'class'=> 'form-control' , 'style' => 'margin-bottom:15px' )))
        ->add( 'type' , ChoiceType::class, array ( 'choices' => array ( 'Music' => 'music' , 'Sport' => 'sport' , 'Movie' => 'movie', 'Theater' => 'theater' ), 'attr'  => array ( 'class' => 'form-control' , 'style' => 'margin-botton:15px' )))
    ->add( 'date' , DateTimeType::class, array ( 'attr'  => array ( 'style' => 'margin-bottom:15px' )))
    ->add( 'save' , SubmitType::class, array ( 'label' => 'Create Event' , 'attr'  => array ( 'class' => 'btn-secondary btn' , 'style' => 'margin-bottom:15px' )))
        ->getForm();
        $form->handleRequest($request);
        
 
         /* Here we have an if statement, if we click submit and if  the form is valid we will take the values from the form and we will save them in the new variables */
         if ($form->isSubmitted() && $form->isValid()){
             //fetching data
 
             // taking the data from the inputs by the name of the inputs then getData() function
            $name = $form[ 'name' ]->getData();
            $image = $form[ 'image' ]->getData();
            $description = $form[ 'description' ]->getData();
            $type = $form[ 'type' ]->getData();
            $date = $form[ 'date' ]->getData();
            $address = $form[ 'address' ]->getData();
            $capacity = $form[ 'capacity' ]->getData();
            $email = $form[ 'email' ]->getData();
            $phone = $form[ 'phone' ]->getData();
            $website = $form[ 'website' ]->getData();
            

 
 /* these functions we bring from our entities, every column have a set function and we put the value that we get from the form */
            $event->setName($name);
            $event->setimage($image);
            $event->setDescription($description);
            $event->settype($type);
            $event->setDate($date);
            $event->setAddress($address);
            $event->setCapacity($capacity);
            $event->setEmail($email);
            $event->setPhone($phone);
            $event->setWebsite($website);
            $em = $this ->getDoctrine()->getManager();
            $em->persist($event);
            $em->flush();
             $this ->addFlash(
                     'notice' ,
                     'Event Added'
                    );
             return   $this ->redirectToRoute( 'test_index' );
        }
 /* now to make the form we will add this line form->createView() and now you can see the form in create.html.twig file  */
         return   $this ->render( 'event/create.html.twig' , array ( 'form'  => $form->createView()));
    }
 
 
     /**
     * @Route("/edit/{id}", name="test_edit", methods={"GET","POST"})
     */
    public  function editAction( $id, Request $request){
        /* Here we have a variable todo and it will save the result of this search and it will be one result because we search based on a specific id */
           $event = $this->getDoctrine()->getRepository('App:Event')->find($id);
        /* Now we will use set functions and inside this set functions we will bring the value that is already exist using get function for example we have setName() and inside it we will bring the current value and use it again */
        $event->setName($event->getName());
        $event->setimage($event->getImage());
        $event->setDescription($event->getDescription());
        $event->settype($event->getType());
        $event->setDate($event->getDate());
        $event->setAddress($event->getAddress());
        $event->setCapacity($event->getCapacity());
        $event->setEmail($event->getEmail());
        $event->setPhone($event->getPhone());
        $event->setWebsite($event->getWebsite());

        $form = $this->createFormBuilder($event)->add( 'name', TextType::class, array ('attr' => array ('class'=> 'form-control' , 'style'=> 'margin-bottom:15px')))
        ->add( 'image', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px')))
        ->add( 'description', TextareaType::class, array( 'attr' => array( 'class'=> 'form-control' , 'style' => 'margin-bottom:15px' )))
        ->add( 'address', TextType::class, array( 'attr' => array( 'class'=> 'form-control' , 'style' => 'margin-bottom:15px' )))
        ->add( 'capacity', TextType::class, array( 'attr' => array( 'class'=> 'form-control' , 'style' => 'margin-bottom:15px' )))
        ->add( 'email', TextType::class, array( 'attr' => array( 'class'=> 'form-control' , 'style' => 'margin-bottom:15px' )))
        ->add( 'phone', TextType::class, array( 'attr' => array( 'class'=> 'form-control' , 'style' => 'margin-bottom:15px' )))
        ->add( 'website', TextType::class, array( 'attr' => array( 'class'=> 'form-control' , 'style' => 'margin-bottom:15px' )))
        ->add( 'type' , ChoiceType::class, array ( 'choices' => array ( 'Music' => 'music' , 'Sport' => 'sport' , 'Movie' => 'movie', 'Theater' => 'theater' ), 'attr'  => array ( 'class' => 'form-control' , 'style' => 'margin-botton:15px' )))
    ->add( 'date' , DateTimeType::class, array ( 'attr'  => array ( 'style' => 'margin-bottom:15px' )))
    ->add( 'save' , SubmitType::class, array ( 'label' => 'Edit Event' , 'attr'  => array ( 'class' => 'btn-secondary btn' , 'style' => 'margin-bottom:15px' )))
        ->getForm();
        $form->handleRequest($request);
        
 
         /* Here we have an if statement, if we click submit and if  the form is valid we will take the values from the form and we will save them in the new variables */
         if ($form->isSubmitted() && $form->isValid()){
             //fetching data
 
             // taking the data from the inputs by the name of the inputs then getData() function
            $name = $form[ 'name' ]->getData();
            $image = $form[ 'image' ]->getData();
            $description = $form[ 'description' ]->getData();
            $type = $form[ 'type' ]->getData();
            $date = $form[ 'date' ]->getData();
            $address = $form[ 'address' ]->getData();
            $capacity = $form[ 'capacity' ]->getData();
            $email = $form[ 'email' ]->getData();
            $phone = $form[ 'phone' ]->getData();
            $website = $form[ 'website' ]->getData();
            $em = $this->getDoctrine()->getManager();
            $em->flush();
             $this ->addFlash(
                     'notice' ,
                     'Event Added'
                    );
             return   $this ->redirectToRoute( 'test_index' );
        }
        return   $this ->render( 'event/edit.html.twig' , array ( 'form'  => $form->createView()));
    }
 
    /**
    * @Route("/{id}", name="test_show", methods={"GET"})
    */
   public function  detailsAction($id)
   {
       $event = $this->getDoctrine()->getRepository( 'App:Event')->find($id);
       return $this->render( 'event/details.html.twig', array('event' => $event));
   }
 

 
    /**
    * @Route("/delete/{id}", name="event_delete")
    */
    public function deleteAction($id)
    {
        $em = $this->getDoctrine()->getManager();
        $event = $em->getRepository('App:Event')->find($id);
        $em->remove($event);
            $em->flush();
            $this->addFlash(
                'notice',
                    'Event Removed'
                );
            return  $this->redirectToRoute('test_index');
    }



    /**
    * @Route("/search/sport", name="search_sport")
    */
    public function searchByType(){
        
         // Here we will use getDoctrine to use doctrine and we will select the entity that we want to work with and we used findby() to bring all search results we need from it and we will save it inside a variable named events and the type of the result will be an array
         $events = $this->getDoctrine()->getRepository( 'App:Event')->findBy(
            ['type' => 'sport']
        );
      
         return $this ->render('event/index.html.twig', array('events'=>$events));
  // we send the result (the variable that have the result of bringing all info from our database) to the index.html.twig page
     
    }



    /**
    * @Route("/search/music", name="search_music")
    */
    public function searchByType2(){
        
         // Here we will use getDoctrine to use doctrine and we will select the entity that we want to work with and we used findby() to bring all search results we need from it and we will save it inside a variable named events and the type of the result will be an array
         $events = $this->getDoctrine()->getRepository( 'App:Event')->findBy(
            ['type' => 'music']
        );
      
         return $this ->render('event/index.html.twig', array('events'=>$events));
  // we send the result (the variable that have the result of bringing all info from our database) to the index.html.twig page
     
    }



    /**
    * @Route("/search/theater", name="search_theater")
    */
    public function searchByType3(){
        
         // Here we will use getDoctrine to use doctrine and we will select the entity that we want to work with and we used findby() to bring all search results we need from it and we will save it inside a variable named events and the type of the result will be an array
         $events = $this->getDoctrine()->getRepository( 'App:Event')->findBy(
            ['type' => 'theater']
        );
      
         return $this ->render('event/index.html.twig', array('events'=>$events));
  // we send the result (the variable that have the result of bringing all info from our database) to the index.html.twig page
     
    }



    /**
    * @Route("/search/movie", name="search_movie")
    */
    public function searchByType4(){
        
         // Here we will use getDoctrine to use doctrine and we will select the entity that we want to work with and we used findby() to bring all search results we need from it and we will save it inside a variable named events and the type of the result will be an array
         $events = $this->getDoctrine()->getRepository( 'App:Event')->findBy(
            ['type' => 'movie']
        );
      
         return $this ->render('event/index.html.twig', array('events'=>$events));
  // we send the result (the variable that have the result of bringing all info from our database) to the index.html.twig page
     
    }
}
 ?>